================================================================================
TẬP ĐOÀN VPS - BỘ BIỂU MẪU BÁO CÁO CHUẨN GỬI CÁC ĐƠN VỊ THÀNH VIÊN
================================================================================

Danh sách các đơn vị áp dụng:
  1. Tân Hồng Hà
  2. Việt
  3. Xem Sơn
  4. VPS M
  5. ITSS
  6. Văn phòng VPS

--------------------------------------------------------------------------------
I. DANH MỤC CÁC FILE BIỂU MẪU ĐÍNH KÈM:
--------------------------------------------------------------------------------
1. 01_Template_Tong_Hop_Bao_Cao_Don_Vi_VPS_Full.xlsx
   => (KHUYẾN NGHỊ SỬ DỤNG): File tổng hợp toàn diện All-in-one gồm đầy đủ 14 sheet:
      - 00_Huong_Dan: Hướng dẫn quy định nhập liệu chung.
      - DOANH SỐ VÀ LÃI GỘP: Chi tiết 8 phòng ban / mảng kinh doanh, KH & TH tháng, năm, tỷ lệ đạt, % lãi gộp tự động.
      - Công nợ: Phải thu trong hạn, quá hạn, nợ khó đòi.
      - Khách hàng: Cơ cấu khách hàng 6 mảng (Thuê máy, MC, DV Photo, In, Đại lý).
      - Tồn kho: Danh mục vật tư, thiết bị, đơn vị tính, số lượng, giá trị (HĐKD & Dự án).
      - Nhân sự: Định biên, tuyển mới, nghỉ việc, thử việc từng phòng ban.
      - Sản Phẩm: Theo hãng (HP, Fujifilm, Khác) và nhóm sản phẩm.
      - Chi Phí: Bảng phân bổ chi phí cố định, biến đổi theo các bộ phận.
      - ISO: Danh mục quy trình, quy định ban hành và áp dụng.
      - Đào tạo: Nội dung đào tạo, đối tượng, kế hoạch & thực tế lượt học.
      - Dịch vụ tận tâm: Chấm điểm kỹ thuật viên, lượt việc, thời gian phục vụ.
      - Văn hóa DN: Chỉ tiêu văn hóa VPS (Nhân quả, Tứ vô lượng tâm, Quy y, Tín chỉ).
      - Thương hiệu: Chỉ tiêu thị phần, độ nhận diện, phát triển khách hàng mới.
      - Dự án & KH Dự án: Chi tiết máy móc, gói thầu các dự án lớn (Agribank, Mobifone...).

2. 02_Mau_Bao_Cao_KQKD_P&L_12_Thang_VPS.xlsx
   => Dành cho Ban Giám đốc & Phòng Kế toán đơn vị lập Báo cáo Kết quả Kinh doanh (P&L) 12 tháng.

3. 03_Mau_Bao_Cao_Chi_Phi_Tong_Hop_VPS.xlsx
   => Dành cho Phòng Kế toán theo dõi chi tiết các khoản chi phí cố định, biến đổi và phân bổ.

4. 04_Mau_Bao_Cao_Cong_No_Chi_Tiet_VPS.xlsx
   => Dành cho Kế toán công nợ theo dõi tuổi nợ và danh sách khách hàng nợ chi tiết.

5. 05_Mau_Bao_Cao_Khach_Hang_Doanh_So_Du_An_VPS.xlsx
   => Dành cho Khối Kinh doanh Dự án theo dõi doanh số máy móc, vật tư tại các chi nhánh dự án.

6. 06_Mau_Bao_Cao_Nhan_Su_Dao_Tao_Van_Hoa_VPS.xlsx
   => Dành cho Phòng Hành chính Nhân sự báo cáo định biên, kết quả đào tạo và tín chỉ văn hóa.

7. 07_Mau_Bao_Cao_Dich_Vu_Tan_Tam_Ky_Thuat_VPS.xlsx
   => Dành cho Phòng Dịch vụ Kỹ thuật đánh giá chất lượng sửa chữa, bảo dưỡng và lượt việc KTV.

--------------------------------------------------------------------------------
II. QUY ĐỊNH NHẬP LIỆU QUAN TRỌNG:
--------------------------------------------------------------------------------
1. Tên Đơn vị: Nhập chính xác tên đơn vị theo đúng quy chuẩn:
   - "Tân Hồng Hà"
   - "Việt"
   - "Xem Sơn"
   - "VPS M"
   - "ITSS"
   - "Văn phòng VPS"
2. Định dạng ngày tháng: Nhập theo mẫu MM/YYYY (Ví dụ: 08/2026, 09/2026...).
3. Định dạng số tiền: Nhập số nguyên dương (đơn vị: VNĐ). Không gõ ký tự chữ "đ", "vnd".
4. Không xóa hoặc chèn thay đổi thứ tự các cột tiêu đề để đảm bảo hệ thống Dashboard tự động đồng bộ số liệu chính xác.

--------------------------------------------------------------------------------
Bộ phận Kỹ thuật & Quản trị Hệ thống Dashboard - Tập đoàn VPS
